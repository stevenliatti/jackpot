var display_8c =
[
    [ "adapt_frequency", "display_8c.html#a2b25650db42bd83a2970a2a7e3adbee3", null ],
    [ "display_machine", "display_8c.html#af1bbe301a3d0aaca2f8c6c912649de67", null ],
    [ "display_thread", "display_8c.html#a1e24f185dae2672541c6df7f8a4b42a8", null ],
    [ "won_coins_compute", "display_8c.html#a9a7ee3716078a695eb5faef4c88db3fd", null ]
];