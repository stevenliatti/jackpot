var machine_8c =
[
    [ "free_machine", "machine_8c.html#a2c434f17a2209b6cd244f576369861ed", null ],
    [ "new_machine", "machine_8c.html#a701c7b4ed54e82de5ed962f74cc04f89", null ]
];