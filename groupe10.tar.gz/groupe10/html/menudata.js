var menudata={children:[
{text:"Page principale",url:"index.html"},
{text:"Pages associées",url:"pages.html"},
{text:"Fichiers",url:"files.html",children:[
{text:"Liste des fichiers",url:"files.html"},
{text:"Variables globale",url:"globals.html",children:[
{text:"Tout",url:"globals.html"},
{text:"Fonctions",url:"globals_func.html"},
{text:"Macros",url:"globals_defs.html"}]}]}]}
