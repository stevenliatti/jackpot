var NAVTREE =
[
  [ "Jackpot", "index.html", [
    [ "Liste des bogues", "bug.html", null ],
    [ "Fichiers", null, [
      [ "Liste des fichiers", "files.html", "files" ],
      [ "Variables globale", "globals.html", [
        [ "Tout", "globals.html", null ],
        [ "Fonctions", "globals_func.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"bug.html"
];

var SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
var SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';