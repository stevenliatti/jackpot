var searchData=
[
  ['jackpot_2ec',['jackpot.c',['../jackpot_8c.html',1,'']]]
];
