var searchData=
[
  ['machine_2ec',['machine.c',['../machine_8c.html',1,'']]],
  ['machine_2eh',['machine.h',['../machine_8h.html',1,'']]],
  ['main',['main',['../jackpot_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'jackpot.c']]]
];
