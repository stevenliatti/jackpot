var searchData=
[
  ['log_5ferror',['LOG_ERROR',['../logger_8h.html#aced66975c154ea0e2a8ec3bc818b4e08',1,'logger.h']]],
  ['log_5flevel',['LOG_LEVEL',['../logger_8h.html#a0b87e0d3bf5853bcbb0b66a7c48fdc05',1,'logger.h']]]
];
