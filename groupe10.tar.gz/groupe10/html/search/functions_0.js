var searchData=
[
  ['adapt_5ffrequency',['adapt_frequency',['../display_8c.html#a2b25650db42bd83a2970a2a7e3adbee3',1,'display.c']]]
];
