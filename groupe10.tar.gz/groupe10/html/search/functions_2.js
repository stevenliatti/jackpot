var searchData=
[
  ['display_5fthread',['display_thread',['../display_8c.html#a1e24f185dae2672541c6df7f8a4b42a8',1,'display_thread(void *arg):&#160;display.c'],['../display_8h.html#a1e24f185dae2672541c6df7f8a4b42a8',1,'display_thread(void *arg):&#160;display.c']]]
];
