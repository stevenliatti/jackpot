var searchData=
[
  ['logger',['logger',['../logger_8c.html#a71d55f7744b79bf8871c21d28581cc73',1,'logger(int log_level, FILE *stream, char *format,...):&#160;logger.c'],['../logger_8h.html#a71d55f7744b79bf8871c21d28581cc73',1,'logger(int log_level, FILE *stream, char *format,...):&#160;logger.c']]]
];
