var searchData=
[
  ['new_5fmachine',['new_machine',['../machine_8c.html#a701c7b4ed54e82de5ed962f74cc04f89',1,'machine.c']]]
];
