var searchData=
[
  ['wheel_5fthread',['wheel_thread',['../wheel_8c.html#af98f8d21ec9db361137aff5ebec0d6fe',1,'wheel_thread(void *arg):&#160;wheel.c'],['../wheel_8h.html#af98f8d21ec9db361137aff5ebec0d6fe',1,'wheel_thread(void *arg):&#160;wheel.c']]],
  ['won_5fcoins_5fcompute',['won_coins_compute',['../display_8c.html#a9a7ee3716078a695eb5faef4c88db3fd',1,'display.c']]]
];
