var indexSectionsWithContent =
{
  0: "acdfjlmnw",
  1: "cdjlmw",
  2: "acdflmnw",
  3: "cl",
  4: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Macros",
  4: "Pages"
};

